just run the 
./run.sh for the entire execution.

(make sure all libraries are installed)