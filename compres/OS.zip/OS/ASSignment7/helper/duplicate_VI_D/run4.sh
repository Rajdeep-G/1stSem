#!/bin/bash

gcc -o my_shell my_shell.c vi_editor.c -lncurses -lreadline
./my_shell
