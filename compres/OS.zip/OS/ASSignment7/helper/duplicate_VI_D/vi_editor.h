// vi_editor.h

#ifndef VI_EDITOR_H
#define VI_EDITOR_H

// Define any function declarations and data structures needed by the vi editor

#endif
