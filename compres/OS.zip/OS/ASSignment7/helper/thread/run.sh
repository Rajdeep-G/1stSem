#!/bin/bash

gcc -o thread th.c -lncurses -lreadline
./thread