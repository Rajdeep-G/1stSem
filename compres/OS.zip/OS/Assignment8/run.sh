gcc f1.c -o f1 -lpthread
./f1
