gcc server.c -o server -lpthread
gcc client.c -o client
./server